package Vodafone.Mobile_Money;

public class Data {
	
	//loginscreen
	public static String un_MSISDN = "70899530";
	public static String Mpin_pwd = "111111";
	
	//OTP screen
	
	public static String OTPvalue_pin1 = "8";
	public static String OTPvalue_pin2 = "8";
	public static String OTPvalue_pin3 = "8";
	public static String OTPvalue_pin4 = "8";
	
	//forgotpage
	public static String forgotpage_MSISDN = "79050100";
	
	//registernow screen
	public static String Regi_MSISDN_value="79050100";
	public static String enterAmounToAdd="10";
		
	//Cashout Detail
	 public static String Cashout_Benificiary_Name = "Hemavathi";
	 public static String Cashout_Benificiary_Address1 = "aaa";
	 public static String Cashout_Benificiary_Address2 = "bbb";
	 public static String Cashout_Benificiary_Address3 = "ccc";
	 public static String Cashout_Mobilenum = "70899330";
	 public static String Cashout_Accnum_IBAN = "QA45MAFR000000000007128654001";
	 //public static String Cashout_Swiftcode = "";
	 public static String Cashout_Bankname = "Masraf Alrayan Bank";
	 public static String Cashout_Branchname = "Doha";
	 public static String Cashout_Purposetranfer = "5/BILL - Bill Payment";
	 public static String Cashout_Relationship = "SELF";
}
