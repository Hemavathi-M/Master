package Vodafone.Mobile_Money;

import org.openqa.selenium.By;

public class OR {
	
	//Language selection
	public static By EnglishBtn=By.id("rbEnglish");
	public static By ArabicBtn=By.id("rbArabic");
	public static By HindiBtn= By.id("rbHindi");
	public static By proceedbtn=By.id("tvProceed");

	//loginscreen
	public static By Username= By.id("etMobileNo");
	public static By m_pin= By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/etMpin']");
	public static By login= By.xpath("//android.widget.TextView[@resource-id='com.mwallet.vfq:id/login']");
	public static By keypad_ok= By.xpath("(//*[@id='key_pos_ime_action'])//*[@class='android.widget.FrameLayout'][1]");
	
	// OTP screen
	public static By Otp_proceedBtn= By.id("tvProcess");
	public static By OTP_Pin1= By.id("aet1");
	public static By OTP_Pin2= By.id("aet2");
	public static By OTP_Pin3= By.id("aet3");
	public static By OTP_Pin4= By.id("aet4");
	public static By OTP_page = By.xpath("(//*[@class='android.widget.LinearLayout'])[3]//*[@class='android.widget.TextView'][1]");
	
	//Forgotpage
	public static By forgot_password= By.id("tvForgotPassword");
	public static By enter_phone= By.id("etMobileNo");
	public static By proceed_btn= By.id("tvProceed");
	public static By Back= By.id("ivBack");
	public static By cancel= By.id("ivCancel");
	public static By click_info= By.xpath("//*[@resource-id='com.mwallet.vfq:id/text_input_end_icon']");  
	public static By Ok=By.id("tvOk");
	
	//registerNow
	
	public static By Registernow_Btn=By.id("tvRegisterNow");
	public static By Regi_MSISDN=By.id("etMobileNo");
	public static By termscondi=By.id("cbTermsCondition");
	public static By scanQID=By.id("etScanQId");
	public static By clk_camera=By.id("ivSelfieCamera");
	public static By Submit_Btn=By.id("tvSubmit");

	//Scan_front_QID
	
	public static By cameraBtn_frontscrn =By.id("ivOpenCamera");	
	public static By clkDeny =By.id("permission_deny_button");
	public static By clkAllow =By.id("permission_allow_button");
	
	//Scan_Back_QID
	public static By cameraBtn_Backscrn=By.id("ivOpenCamera");
	
	//Proceed screen
	public static By Proceed_Btn=By.id("tvProceed");
	
	//Start recording
	public static By Selfie_camera=By.id("ivSelfieCamera");
	public static By StartRecord_Btn=By.id("video");
	public static By Usethis_video=By.id("video");
	public static By Retake_video=By.id("retake");
		
	
	// Dashboard
	public static By Login_Username = By.xpath("//*[@id='tvName']");
	public static By Dashboard_Amount = By.xpath("//*[@id='atvAmount']");
	public static By Cashflow = By.xpath("//*[@id='aivCashFlow']");
	public static By Transfers = By.xpath("//*[@id='aivTransfer']");
	public static By Beneficiary = By.xpath("//*[@id='aivPayments']");
	public static By Rewards = By.xpath("//*[@id='rewards']");
	public static By Rewards_Message = By.xpath("//*[@id='rewardsText']");
	public static By Favorite = By.xpath("//*[@id='menu_favorite']");
	public static By Trasactions = By.xpath("//*[@id='menu_passbook']");
	public static By Index = By.xpath("//*[@id='menu_inbox']");
	public static By Settings = By.xpath("//*[@id='menu_settings']");
	public static By Home = By.xpath("//*[@id='menu_home']");
	public static By Assistance_FAQ = By.xpath("//*[@id='assistance']");
	public static By Assistance_Arrow = By.xpath("//*[@id='arrow']");

	// Cash Flow
		// 1. Cash-in
	public static By Cash_In = By.xpath("(//*[@class='androidx.appcompat.app.ActionBar$Tab']/*)[1]");
	public static By EnterAmountToAdd = By.xpath("//*[@class='android.widget.EditText']");
	public static By Proceed_btn = By.xpath("//*[@id='tvProceed']");

		// 2. Cash-Out
	public static By Cash_Out = By.xpath("(//*[@class='androidx.appcompat.app.ActionBar$Tab']/*)[2]");
	
	//Settings screen
	public static By setting_Button = By.id("menu_settings");
	public static By Proceed = By.xpath("//android.widget.TextView[@resource-id='com.mwallet.vfq:id/tvProceed']");
	public static By Mobile_Number = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/etMobileNo']");
	public static By M_PIN = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/etMpin']");
	public static By Login = By.xpath("//android.widget.TextView[@resource-id='com.mwallet.vfq:id/login']"); 
	public static By OTP1 = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/aet1']");
	public static By OTP2 = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/aet2']");
	public static By OTP3 = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/aet3']");
	public static By OTP4 = By.xpath("//android.widget.EditText[@resource-id='com.mwallet.vfq:id/aet4']");
	public static By OTP_Proceed = By.xpath("//android.widget.TextView[@resource-id='com.mwallet.vfq:id/tvProcess']");
	
	//My profile QR Code
	public static By My_Profile_Icon = By.id("ivMyProfileRightArrow");
	public static By My_Profile_downarrow = By.xpath("(//*[@class='android.widget.ImageView'])[3]");
	
	
	//Change Language
	public static By Change_your_language_Arrow = By.id("arrow2");
	public static By Change_Your_Language_Change_Button = By.id("tvChangeLang");
	public static By Hindhibtn = By.id("rbHindi");
	public static By Englishbtn=By.id("rbEnglish");
	
	//Personal Details
	public static By Personal_details_Arrow=By.id("arrow3");
	public static By Back_Arrow=By.id("ivBack");
    public static By Personal_Details_Save =By.id("tvSave");
    public static By Personal_details_UpdateQID=By.id("updateQID");
	
    //change Number
  	public static By Changenumber_arrow=By.id("arrow4");
  	public static By Changenumber_Text1 =By.xpath("(//*[@class='android.widget.LinearLayout' and ./parent::*[@class='android.widget.RelativeLayout']]/*[@text])[1]");
  	public static By Changenumber_Text2 =By.xpath("(//*[@class='android.widget.LinearLayout' and ./parent::*[@class='android.widget.RelativeLayout']]/*[@text])[2]");
  	public static By Change_number_countrycode=By.xpath("//*[@id='tvCountryCode']");
  	public static By Change_number_MSISDN=By.xpath("//*[@id='mobile']");
  	public static By Send_OTP_Icon=By.xpath("//*[@id='sendOtp']");
  	public static By change_number_text3=By.xpath("//*[@id='enterotp']");
  	public static By change_number_OTP1=By.xpath("//*[@id='aet1']");
  	public static By change_number_OTP2=By.xpath("//*[@id='aet2']");
  	public static By change_number_OTP3=By.xpath("//*[@id='aet3']");
  	public static By change_number_OTP4=By.xpath("//*[@id='aet4']");
  	public static By Chang_Number_Auto_fill_code_text1=By.xpath("//*[@id='text1']");
  	public static By Chang_Number_Auto_fill_code_text2=By.xpath("//*[@id='text2']");
  	public static By Changenumber_Inportant_text2=By.xpath(" (//*[@class='android.widget.TextView'])/*[@class='android.widget.TextView'][0]");
  	public static By Changenumber_Inportant_text3=By.xpath(" (//*[@class='android.widget.TextView'])/*[@class='android.widget.TextView'[1]");
  	public static By change_number_Submit_button=By.xpath("//*[@id='tvProcess']");
 
  	
  	//cashout account
  	public static By cashout_acc_arrow=By.xpath("//*[@id='arrow5']");
  	public static By cashout_accout_1=By.xpath("(//*[@id='beneficiaryList']/*[@id='parentCl'])[1]");
	public static By cashout_accout_2=By.xpath("(//*[@id='beneficiaryList']/*[@id='parentCl'])[2]");
	public static By cashout_account_newbenifisier=By.xpath("//*[@id='tvAddNew']");
	
	public static By Cashout_New_benificiary=By.id("tvAddNew");
	public static By Cashout_Benificiary_Name=By.id("atvBeneName");
	public static By Cashout_Benificiary_Address1=By.id("atvAddressOne");
	public static By Cashout_Benificiary_Address2=By.id("atvAddressTwo");
	public static By Cashout_Benificiary_Address3=By.id("atvAddressThree");
	public static By Cashout_Mobilenum=By.id("atvMobile");
	public static By Cashout_Accnum=By.id("atvAccountNumber");
	public static By Cashout_Swiftcode=By.id("atvSwiftCode");
	public static By Cashout_Bankname=By.xpath("(//*[@class='android.widget.ListView'])");
	//(//*[@resource-id='com.mwallet.vfq:id/details'])[1]
	
	public static By Cashout_Branchname=By.xpath("//*[@class='android.widget.ListView']");
	//(//*[@resource-id='com.mwallet.vfq:id/details'])[2]
	public static By Cashout_Purposetranfer=By.xpath("//*[@class='android.widget.ListView']");
	//(//*[@resource-id='com.mwallet.vfq:id/details'])[3]
	public static By Cashout_Relationship=By.xpath("//*[@class='android.widget.ListView']");
	//(//*[@resource-id='com.mwallet.vfq:id/details'])[4]
	public static By Cashout_Proceedtoverify=By.id("tvProceed");
	
	//Favorites
	public static By Clk_favoriteBtn = By.xpath("(//*[@id='menu_favorite'])[1]//*[@id='smallLabel']");
	public static By Clk_walletTowallet = By.xpath("(//*[@class='android.widget.LinearLayout'])[5]//*[@class='android.widget.ImageView'][2]");
	public static By Clk_InternationTransfer = By.xpath("(//*[@id='international']/*[@class='android.widget.ImageView'])[2]");
	public static By Clk_LocalTransfer = By.xpath("(//*[@id='local']/*[@class='android.widget.ImageView'])[2]");
	public static By Clk_Cashout = By.xpath("(//*[@id='cashOut']/*[@class='android.widget.ImageView'])[2]");
	
	//password setting
	
	public static By Password_Setting_Arrow=By.id("ivPasswordSettingsRightArrow");
	//old pin
	public static By Oldpin1 =By.id("aetOldMPin1");
	public static By Oldpin2 =By.id("aetOldMPin2");
	public static By Oldpin3 =By.id("aetOldMPin3");
	public static By Oldpin4 =By.id("aetOldMPin4");
	public static By Oldpin5 =By.id("aetOldMPin5");
	public static By Oldpin6 =By.id("aetOldMPin6");
	
	//New pin
	public static By Newpin1=By.id("aetNewMPin1");
	public static By Newpin2=By.id("aetNewMPin2");
	public static By Newpin3=By.id("aetNewMPin3");
	public static By Newpin4=By.id("aetNewMPin4");
	public static By Newpin5=By.id("aetNewMPin5");
	public static By Newpin6=By.id("aetNewMPin6");
	
	//Re-enterPIN
	public static By ReMpin1=By.id("aetReMPin1");
	public static By ReMpin2=By.id("aetReMPin2");
	public static By ReMpin3=By.id("aetReMPin3");
	public static By ReMpin4=By.id("aetReMPin4");
	public static By ReMpin5=By.id("aetReMPin5");
	public static By ReMpin6=By.id("aetReMPin6");
	
	public static By Password_ChangeBtn=By.id("tvChangePin");
	
	
	//Assistance FAQ
	public static By Assistance_FAQ_Arrow= By.id("arrow");
	//--------exchange rates
	
	public static By Assistance_Exchage_Arrow = By.id("ivMyProfileRightArrow");
	public static By Exchange_selectcountry = By.xpath("(//*[@resource-id='com.mwallet.vfq:id/tvSelectCountry'])");
	//resource-id-----com.mwallet.vfq:id/tvSelectCountry
	//tvSelectCountry
	//By.id("tvSelectCountry");
	public static By Exchange_country = By.id("tvCountry");
	public static By Exchange_Amount_to_be_paid = By.id("edRecvAmount");
	
	public static By Paid_Amount = By.id("edSenderAmount");
	//llSendingAmountInfo
	//edSenderAmount
	public static By Amount_Currency = By.id("tvRecieverCurrency");
	public static By Amount_Recieved = By.id("edRecvAmount");
	public static By Amount_Conversation = By.id("tvConversionInfo");
	public static By Submit = By.id("tvProceedToConfirm");
	
	//---------Get help
	public static By Assistance_Get_Help_Arrow= By.id("ivPasswordSettingsRightArrow");
	//---------------------Tutorials
	public static By Assistance_Get_Help_Tutorials = By.id("ivTutorialsRightArrow");
	//-------------------------Tutorial screen
	public static By Assistance_Get_Help_Tutorials_ipay = By.id("ivTopicIcon");
	//--------------------------------Q & A 
	public static By Assistance_Get_Help_QandA = By.id("ivQAndARightArrow");
	public static By Assistance_Get_Help_QandA_Search = By.id("search");
	//-----------------------------------Feedback screen
	public static By Assistance_Feedback_Screen = By.id("ivFeedbackRightArrow");
	public static By Assistance_Feedback_Showmore=By.id("showMore");
	public static By Assistance_Feedback_Screen_All = By.xpath("(//*[@class='android.widget.TextView'])[4]");
	public static By Assistance_Feedback_Screen_Close = By.xpath("(//*[@class='android.widget.TextView'])[6]");
	public static By Assistance_Feedback_Screen_Open = By.xpath("(//*[@class='android.widget.TextView'])[5]");
	public static By Showmore = By.id("showMore");
	public static By Assistance_NeedMorehelp_Screen = By.id("ivFeedbackRightArrow");
	//feedback_New
	public static By Select_Type = By.id("details");
	public static By Select_type_List1=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[2]");
	public static By Select_type_List2=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[3]");
	public static By Select_type_List3=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[4]");
	public static By Select_type_List4=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[5]");
	
	//category 
		public static By Category_Type=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[2]");
		public static By Category_Type1=By.xpath("(//*[@class='android.widget.TextView'])[2]");
		public static By Category_Type2=By.xpath("(//*[@class='android.widget.TextView'])[3]");
		public static By Category_Type3=By.xpath("(//*[@class='android.widget.TextView'])[4]");
		//write request
		public static By write_request=By.xpath("(//*[@resource-id='com.mwallet.vfq:id/request_detail'])");
		//Back icon
		public static By Back_Mobile_icon =By.id("back");
		//rs----------com.android.systemui:id/back
		//Attachement document
		public static By Attachement_document =By.id("text");
		//com.mwallet.vfq:id/text
		//popup screen
		public static By Allow_Up =By.id("permission_allow_button");
		public static By Attachement_document1 =By.id("tvText1");
		public static By Attachement_image1 =By.id("icon_thumb");
		public static By Attachement_document2 =By.id("tvText2");
		public static By Attachement_image2 =By.id("icon_thumb");
		public static By Attachement_document3 =By.id("tvText3");
		public static By Attachement_image3 =By.id("icon_thumb");
		public static By Attachement_OK =By.id("btnOk");
		public static By Submit_request =By.id("tvSave");
		
		
		
		//(//*[@resource-id='com.mwallet.vfq:id/text'])
		//(//*[@resource-id='com.mwallet.vfq:id/request_detail'])	
		
		//(//*[@class='android.widget.TextView'])[2]
		
				//(//*[@class='android.widget.TextView'])[4]
	//com.mwallet.vfq:id/details
	//spinnerCategoryValidate
	//id //request_detail
	//id //text
	//select type
	//(//*[@resource-id='com.mwallet.vfq:id/details'])[1]
	
	//write request
	//(//*[@resource-id='com.mwallet.vfq:id/request_detail'])
	
	//Attachement document
	//(//*[@resource-id='com.mwallet.vfq:id/text'])
	
	//id  ---tvSave
	
	//attached document validation
	//id------tvTitle-----Attach Document
	//id------tvText1-----Attach Document 1
	//id------tvText2-----Attach Document 2
	//id------tvText3----Attach Document 3
	//id------btnOk---OK
	//id------btnCancel-----Cancel
	
	//New Inputs
	
	
	//Locate Uss:
	public static By Assistance_Locateus = By.id("ivPaymentSettingsRightArrow");
}
