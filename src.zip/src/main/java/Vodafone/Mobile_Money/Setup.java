package Vodafone.Mobile_Money;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

/**
 * Hello world!
 *
 */
public class Setup 
{
	@SuppressWarnings("rawtypes")
	public static ThreadLocal<AppiumDriver> driver = new ThreadLocal<AppiumDriver>();
	public final static String Root = System.getProperty("user.dir");
	public DateFormat dateformat = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
	public Calendar cal = Calendar.getInstance();
	public String trfold = dateformat.format(cal.getTime());
	private static AppiumDriverLocalService service;
	
	public static void App_Launch() throws IOException {
		
		//Launch the Mobile Money app setup
		
    	String device_name = ReadMobileproperties("device", "DeviceName");
    	String Version = ReadMobileproperties("device", "version");
		String package_name = ReadMobileproperties("device", "apppackage");
		String activity_name = ReadMobileproperties("device", "appactivity");
		String port = ReadMobileproperties("device", "port");
		
    	DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", device_name);
		capabilities.setCapability("platformVersion", Version);
		capabilities.setCapability("platformName", "ANDROID");
		capabilities.setCapability("appPackage", package_name);
		capabilities.setCapability("appActivity", activity_name);
		
		//starter(port);
		
		try {
			driver.set(new AndroidDriver(new URL("http://127.0.0.1:"+port+"/wd/hub"), capabilities));
		} catch (MalformedURLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		driver.get().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	}
	
		
	public static String ReadMobileproperties(String fname, String propname) throws IOException {
		
		//Read properties file for capability
		
		String fpath = Root + "\\config\\device.properties";
		Properties prop = new Properties();
		FileInputStream input = new FileInputStream(fpath);
		prop.load(input);
		return prop.getProperty(propname);
	}
	
	public static void starter(String port) {

	    //Build the Appium service
		
	    AppiumServiceBuilder builder = new AppiumServiceBuilder();
	    builder.withIPAddress("127.0.0.1");
	    int port1 = Integer.parseInt(port);
	    builder.usingPort(port1);
	    builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
	    builder.withArgument(GeneralServerFlag.LOG_LEVEL,"error");
	    
	    //Start the server with the builder
	    AppiumDriverLocalService service = AppiumDriverLocalService.buildService(builder);
	    service.start();
	}
}
