package Vodafone.Mobile_Money;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import Vodafone.Mobile_Money.Data;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class Execution extends Setup {

	public final String Input_Sheet = Root + "\\config\\";
	public final String Result_FLD = System.getProperty("user.dir") + "\\Result";
	public String Expected_Text = "";
	public String Actual_Text = "";
	public String Status = "No Run";
	public String Update_Result = "";
	public File resfold = null;
	public String timefold = "";
	public DateFormat For = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
	public String ExecutionStarttime = For.format(cal.getTime()).toString();
	public String curtcid = "";

	@Test
	public void Validation() {

		try {
			App_Launch();
		} catch (IOException e) {
			System.out.println("Problem with mobile setup process");
		}
		try {
			Assertion();
		} catch (IOException e) {
			System.out.println("Problem in provided input data");
		}
	}

	public void Assertion() throws IOException {

		String File = ReadMobileproperties("device", "FileName");
		Fillo fillo = new Fillo();
		try {
			Connection conn = fillo.getConnection(Input_Sheet + File);
			createtimestampfold();
			ExtentReports extent = new ExtentReports();
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(trfold + "\\Master.html");
			extent.attachReporter(htmlReporter);
			// Select the screen to be validated
			System.out.println("Selecting the page for execution....");
			String inputQuery = "Select * from Execution where Execution = 'Yes'";
			Recordset inputs = conn.executeQuery(inputQuery);
			while (inputs.next()) {
				String Language = ReadMobileproperties("device", "LanguageToTest");
				String Screen_Name = inputs.getField("Screen Name").replaceAll(" ", "_");
				ExtentTest test = extent.createTest("<b>Language: </b>" + Language + "<br><b>Screen Name: </b>" + Screen_Name);
				System.out.println(Screen_Name + " ---> Started Execution");
				Class<?> noparams[] = {};
				Class<?> cls;
				try {
					cls = Class.forName("Pages." + Screen_Name);
					Object obj = null;
					try {
						obj = cls.newInstance();
					} catch (InstantiationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					java.lang.reflect.Method method1 = cls.getDeclaredMethod(Screen_Name, noparams);
					method1.invoke(obj);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Get the screen details
				String Select_Screen = "Select * from " + Screen_Name + " where Execution = 'Yes'";
				Recordset Screen_details = conn.executeQuery(Select_Screen);

				while (Screen_details.next()) {
					String Method_Name = Screen_details.getField("Event/Trigger").replaceAll(" ", "_");
					//ExtentTest test = extent.createTest("<b>Language: </b>" + Language + "<br><b>Screen Name: </b>" + Screen_Name+"<br><b>Event/Trigger: </b>"+Screen_details.getField("Event/Trigger"));
					try {
						takeScreenShot(Screen_Name + "_" + Method_Name);
					} catch (IOException e1) {
						System.out.println("Problem in taking screenshot");
					} catch (InterruptedException e1) {
						System.out.println("Problem in taking screenshot");
					}
					String Element = Screen_details.getField("Elements");
					try {
						cls = Class.forName("Pages." + Screen_Name);
						Object obj = null;
						try {
							obj = cls.newInstance();
						} catch (InstantiationException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						java.lang.reflect.Method method2 = cls.getDeclaredMethod(Method_Name, noparams);
						method2.invoke(obj);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					String identifier = Screen_details.getField("Identifier");

					if (Language.equalsIgnoreCase("English")) {
						Expected_Text = Screen_details.getField("Message EN").replaceAll("'", "");
					} else if (Language.equalsIgnoreCase("Hindi")) {
						Expected_Text = Screen_details.getField("Message HN");
					} else {
						Expected_Text = Screen_details.getField("Message AR");
					}

					try {
						if (identifier.equalsIgnoreCase("xpath")) {
							Actual_Text = driver.get().findElement(By.xpath(Element)).getText().replaceAll("'", "");
						} else {
							Actual_Text = driver.get().findElement(By.id(Element)).getText().replaceAll("'", "");
						}

						System.out.println("Actual Text: " + Actual_Text);

						try {
							assertEquals(Expected_Text, Actual_Text);
							Status = "Pass";
						} catch (AssertionError e) {
							Status = "Fail";
						}

					} catch (Exception e) {
						System.out.println("Provide Element is not found");
						Status = "Element not found";
						Actual_Text = "Null";
					}
					String Number = Screen_details.getField("Sno");
					if (Language.equalsIgnoreCase("English")) {
						Update_Result = "Update " + Screen_Name + " Set Actual_Message_EN = '" + Actual_Text
								+ "', EN_Result = '" + Status + "' where Sno = '" + Number + "' ";
					} else if (Language.equalsIgnoreCase("Hindi")) {
						Update_Result = "Update " + Screen_Name + "Set Actual_Message_HN = '" + Actual_Text
								+ "' and HN_Result = '" + Status + "'";
					} else {
						Update_Result = "Update " + Screen_Name + "Set Actual_Message_AR = '" + Actual_Text
								+ "' and AR_Result = '" + Status + "'";
					}

					System.out.println("Update: " + Update_Result);
					conn.executeUpdate(Update_Result);
					String screenshot = Screen_Name + "_" + Method_Name + ".png";

					if (Status.equalsIgnoreCase("Pass")) {
						test.pass("</table><table><tr><th style= 'min-width: 168px'><b>Page Name</b></th>"
								+ "<th style= 'min-width: 168px'><b>Event/Trigger</b></th><th style= 'min-width: 168px'><b>Expected Text</b></th>"
								+ "<th style= 'min-width: 168px'><b>Actual Text</b></th><th style= 'min-width: 168px'><b>Screenshot</b></th>"
								+ "<th style= 'min-width: 168px'><b>Status</b></th></tr>" +

//Device Result
								"<tr><td style= 'min-width: 168px'>" + Screen_Name
								+ "</td><td style= 'min-width: 168px'>" + Screen_details.getField("Event/Trigger")
								+ "</td><td style= 'min-width: 168px'>" + Expected_Text
								+ "</td><td style= 'min-width: 168px'>" + Actual_Text
								+ "</td><td style= 'min-width: 168px'>" + "<a href='Screenshots/"+ screenshot+"' target='_blank'>"+Screen_Name+"-->"+Method_Name+"</a></td><td style= 'min-width: 168px'>"
								+ Status + "</td></tr><br>");
					} else {
						test.fail("</table><table><tr><th style= 'min-width: 168px'><b>Page Name</b></th>"
								+ "<th style= 'min-width: 168px'><b>Event/Trigger</b></th><th style= 'min-width: 168px'><b>Expected Text</b></th>"
								+ "<th style= 'min-width: 168px'><b>Actual Text</b></th><th style= 'min-width: 168px'><b>Screenshot</b></th>"
								+ "<th style= 'min-width: 168px'><b>Status</b></th></tr>" +

								// Device Result
								"<tr><td style= 'min-width: 168px'>" + Screen_Name
								+ "</td><td style= 'min-width: 168px'>" + Screen_details.getField("Event/Trigger")
								+ "</td><td style= 'min-width: 168px'>" + Expected_Text
								+ "</td><td style= 'min-width: 168px'>" + Actual_Text
								+ "</td><td style= 'min-width: 168px'>" + "<a href='Screenshots/"+screenshot
								+ "' target='_blank'>"+Screen_Name+"-->"+Method_Name+"</a></td><td style= 'min-width: 168px'>"
								+ Status + "</td></tr><br>");
					}
				}
			}
			extent.flush();
		} catch (FilloException e) {
			System.out.println(e);
			System.out.println(File + " - File not found!!!");
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void createtimestampfold() {
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		try {
			resfold = new File(Result_FLD + "/" + dateFormat.format(cal.getTime()) + "/");
			if ((!resfold.exists()))
				resfold.mkdir();
			timefold = ExecutionStarttime.replace(":", "-").replace(" ", "_");
			File tresfold = new File(resfold + "/" + timefold + "/");
			if ((!tresfold.exists()))
				tresfold.mkdir();
			trfold = tresfold.toString();
			System.out.println("Path: " + trfold);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void takeScreenShot(String scdesc) throws IOException, InterruptedException {
		// Set folder name to store screenshots.
		String destDir = trfold+"//Screenshots//";
		// Capture screenshot.
		File scrFile = ((TakesScreenshot) driver.get()).getScreenshotAs(OutputType.FILE);
		// Set date format to set It as screenshot file name.
		// Create folder under project with name "screenshots" provided to destDir.
		new File(destDir).mkdirs();
		// Set file name using current date time.
		String destFile = scdesc + ".png";

		try {
			// Copy paste file at destination folder location
			FileUtils.copyFile(scrFile, new File(destDir + "/" + destFile));
			// Thread.sleep(5000);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public static void verticalscroll() {
        Dimension size = driver.get().manage().window().getSize();
        int anchor = (int) (size.width * 0.5);
        int startPoint = (int) (size.height * 0.5);
        int endPoint = (int) (size.height * 0.1);
        new TouchAction(driver.get()).press(PointOption.point(anchor, startPoint)).waitAction()
                .moveTo(PointOption.point(anchor, endPoint)).release().perform();
    }
	
	public void verticalscroll_up() {
        Dimension size = driver.get().manage().window().getSize();
        int anchor = (int) (size.width * 0.5);
        int startPoint = (int) (size.height * 0.5);
        int endPoint = (int) (size.height * 0.9);
        new TouchAction(driver.get()).press(PointOption.point(anchor, startPoint)).waitAction()
                .moveTo(PointOption.point(anchor, endPoint)).release().perform();
    }

}
