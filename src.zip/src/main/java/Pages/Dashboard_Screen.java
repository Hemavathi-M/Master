package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Dashboard_Screen extends Execution {

	public void Dashboard_Screen() throws InterruptedException {

		// Language Selection
		driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get().findElement(By.xpath("//*[@resource-id='com.mwallet.vfq:id/tvProceed']")).click();

		// Login
		driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMobileNo']")).click();
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMobileNo']"))
				.sendKeys(Data.un_MSISDN);

		new WebDriverWait(driver.get(), 10).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMpin']")));
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMpin']")).sendKeys(Data.Mpin_pwd);

		driver.get().navigate().back();

		new WebDriverWait(driver.get(), 30).until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@resource-id ='com.mwallet.vfq:id/login']")));
		driver.get().findElement(By.xpath("//*[@resource-id ='com.mwallet.vfq:id/login']")).click();
		Thread.sleep(1000);
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet1']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet2']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet3']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet4']")).sendKeys("8");


	}

	public void DashboardScreenTest1() throws InterruptedException {
        Thread.sleep(1000);
		System.out.println("Dashboard Screen validation");
	}

	public void Dashboard_Screen_Scroll() throws InterruptedException {
		// Dashboard
		System.out.println(" ********* Scroll the Dashboard  ***************");
		verticalscroll();
		
	}
}

