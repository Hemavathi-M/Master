package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Setting_Personal_Details extends Execution {
	public void Setting_Personal_Details() {
		System.out.println("------- Settingscreen_Personaldetails_screen -----");
		verticalscroll();
		driver.get().findElement(OR.Personal_details_Arrow).click();
	}

	public void Settings_My_profile_Personal_Details() {
		System.out.println("------- Settings_My Screen_Personal_Details_screen -----");
	}
	
	public void Settings_Personal_Details_Scroll() {
		verticalscroll();
	}
	
	public void Settings_Personal_QID_Details() {
		System.out.println("------- Settings_My Screen_Personal_Details_Update_QID -----");
		verticalscroll();
		driver.get().findElement(OR.Personal_details_UpdateQID).click();
	}
	
	public void Settings_Back_to_Profile() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}

}
