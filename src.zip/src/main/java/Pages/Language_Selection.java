package Pages;

import org.openqa.selenium.WebElement;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Language_Selection extends Execution {

	public void Language_Selection() {
		System.out.println("------- Language Selection -----");
	}

	public void Language_Assertion() {
		System.out.println("------- Language Assertion -----");
	}
	
}