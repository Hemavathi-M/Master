package Pages;

import java.util.ArrayList;

import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codoid.products.fillo.Select;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class New_Add_cash_out_account extends Execution {
	
	public void New_Add_cash_out_account()
	{
		new WebDriverWait(driver.get(), 60).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
	 driver.get().findElement(OR.Back_Arrow).click(); 
	 new WebDriverWait(driver.get(), 120).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("tvAddNew")));
	 driver.get().findElement(OR.Cashout_New_benificiary).click(); 

	 }
	
	//Assertion part
	public static void New_Add_cash_out_account_flow()
	{
		System.out.println("------- New_benificier_add_cashout -----");
	}
	
	public static void New_Add_Beneficiary_Details()
	{
		new WebDriverWait(driver.get(), 30).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("atvBeneName")));
		 driver.get().findElement(OR.Cashout_Benificiary_Name).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Name).sendKeys(Data.Cashout_Benificiary_Name);
		 driver.get().findElement(OR.Cashout_Benificiary_Address1).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address1).sendKeys(Data.Cashout_Benificiary_Address1);
		 driver.get().findElement(OR.Cashout_Benificiary_Address2).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address2).sendKeys(Data.Cashout_Benificiary_Address2);
		 driver.get().findElement(OR.Cashout_Benificiary_Address3).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address3).sendKeys(Data.Cashout_Benificiary_Address3); 
		 driver.get().findElement(OR.Cashout_Mobilenum).click();
		 driver.get().findElement(OR.Cashout_Mobilenum).sendKeys(Data.Cashout_Mobilenum);
		 driver.get().findElement(OR.Cashout_Accnum).click();
		 driver.get().findElement(OR.Cashout_Accnum).sendKeys(Data.Cashout_Accnum_IBAN);
		 driver.get().findElement(OR.Cashout_Bankname).click();
		 String Bank_Name=driver.get().findElement(OR.Cashout_Bankname).getText();
		 System.out.println(Bank_Name);
//		 WebElement testDropDown = ((WebElement) driver).findElement(By.xpath("(//*[@resource-id='com.mwallet.vfq:id/details'])[1]"));
//		 Select dropdown = new Select(testDropDown, Actual_Text); 
		// System.out.println("actual text:"+dropdown);
		 driver.get().findElement(OR.Cashout_Branchname).click();
		 //Select dropdown1 = new Select(testDropDown, Actual_Text); 
		 //System.out.println("actual text:"+dropdown1);
		 driver.get().findElement(OR.Cashout_Branchname).sendKeys(Data.Cashout_Branchname);
		 driver.get().findElement(OR.Cashout_Purposetranfer).click();
		 driver.get().findElement(OR.Cashout_Purposetranfer).sendKeys(Data.Cashout_Purposetranfer);
		 driver.get().findElement(OR.Cashout_Relationship).click();
		 driver.get().findElement(OR.Cashout_Relationship).sendKeys(Data.Cashout_Relationship);
		 
		 driver.get().findElement(OR.Cashout_Proceedtoverify).click();
		 
		 new WebDriverWait(driver.get(), 30).until(
		            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
			  driver.get().findElement(OR.Back_Arrow).click(); 
		       new WebDriverWait(driver.get(), 30).until(
			            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
			 driver.get().findElement(OR.Back_Arrow).click(); 
			 new WebDriverWait(driver.get(), 30).until(
			            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
			 driver.get().findElement(OR.Back_Arrow).click(); 
		      driver.get().findElement(OR.Password_Setting_Arrow).click(); 
			 new WebDriverWait(driver.get(), 30).until(
			            ExpectedConditions.presenceOfElementLocated(By.id("aetOldMPin1")));		 
		 
	}
	
	
}
