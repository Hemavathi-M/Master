package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_Exchange_rates extends Execution  {

	
	public void Assistance_Exchange_rates()
	{
		//click on FAQ arrow
		driver.get().findElement(OR.Assistance_Exchage_Arrow).click();
	}
	
	public  void Assistance_Exchange_rates_screen()
	{
		System.out.println(" ********* Assistance Screen Exchage rates validation ***************");
	}
	public void Assistance_Exchange_rates_screen_flow() throws InterruptedException
	{
		//Execution flow
		Thread.sleep(3000);
		
		
		driver.get().findElement(OR.Exchange_selectcountry).click();
		//Thread.sleep(3000);
		driver.get().findElement(OR.Exchange_country).click();
		driver.get().findElement(OR.Exchange_Amount_to_be_paid).sendKeys("10");
		String Amount_Currency=driver.get().findElement(OR.Amount_Currency).getText();
		System.out.println("Recived Amount :"+Amount_Currency);
		String Amount_Recieved=driver.get().findElement(OR.Amount_Recieved).getText();
		System.out.println("Recived Amount :"+Amount_Recieved);
		String Amount_Conversation=driver.get().findElement(OR.Amount_Conversation).getText();
		System.out.println("Recived Amount :"+Amount_Conversation);
	}
	public void Assistance_Exchange_rates_screen_validation()
	{
		System.out.println(" ********* Assistance Screen Exchage rates validation ***************");
		
	}
	public void Assistance_Exchange_rates_Submit()
	{
		driver.get().findElement(OR.Submit).click();
		String toastMessage3 = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
		  System.out.println("Received Toast Message :"+toastMessage3);
		
	}
	
	public void Back_to_Page() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
}
