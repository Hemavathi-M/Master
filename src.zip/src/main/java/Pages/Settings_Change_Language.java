package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Settings_Change_Language extends Execution {

	public void Settings_Change_Language() {
		System.out.println("------- My_Profile_ChangeLanguage_screen -----");
		driver.get().findElement(OR.setting_Button).click();
		driver.get().findElement(OR.My_Profile_Icon).click();
		driver.get().findElement(OR.Change_your_language_Arrow).click();

	}

	public void Settings_My_profile_Change_language() {
		System.out.println("------- Settings_My Scree_change_language_flow -----");
	}

}
