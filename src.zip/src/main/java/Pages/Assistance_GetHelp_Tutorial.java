package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_GetHelp_Tutorial extends Execution{
	public void Assistance_GetHelp_Tutorial()
	{
		driver.get().findElement(OR.Assistance_Get_Help_Tutorials).click();
	}
	public static void Assistance_GetHelp_Tutorial_screen_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help Tutorials validation ***************");
	}
	
	public static void GetHelp_Tutorial_ipay_Flow()
	{
		driver.get().findElement(OR.Assistance_Get_Help_Tutorials_ipay).click();
	}
	
	public static void GetHelp_Tutorial_ipay_Flow_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help Tutorials validation ***************");
	}
	public static void Assistanvce_Back_GetHelp_Screen1() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
	public static void Assistanvce_Back_GetHelp_Screen2() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
//	public static void Assistanvce_Back_GetHelp_Screen3() {
//		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
//		driver.get().navigate().back();
//	}
}
