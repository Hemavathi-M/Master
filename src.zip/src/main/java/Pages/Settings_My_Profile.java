package Pages;

import java.awt.List;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Settings_My_Profile extends Execution {

	public void Settings_My_Profile() {
		System.out.println("------- Settings My profile screen-----");
		driver.get().findElement(OR.My_Profile_Icon).click();
	}

	public void Settings_My_profile_screen_Flow() {
		System.out.println("------- Settings_My Scree_flow -----");
	}
	
//	public void Back_to_Settings_screen() {
//		System.out.println("------- Back to Settings Screen -----");
//		driver.get().navigate().back();
//	}
}
