package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Setting_Change_Number extends Execution {
	//Adding Inputs Into the change number screen
public void Setting_Change_Number()
{
    new WebDriverWait(driver.get(), 30).until(
            ExpectedConditions.presenceOfElementLocated(By.id("arrow4")));
    driver.get().findElement(OR.Changenumber_arrow).click();
    
    
   
   driver.get().findElement(OR.Change_number_MSISDN).click();
   new WebDriverWait(driver.get(), 30).until(
           ExpectedConditions.presenceOfElementLocated(By.id("mobile")));
    driver.get().findElement(OR.Change_number_MSISDN).sendKeys("79050100");
    new WebDriverWait(driver.get(), 120).until(
            ExpectedConditions.presenceOfElementLocated(By.id("aet1")));
    driver.get().findElement(OR.change_number_OTP1).sendKeys("8");
    new WebDriverWait(driver.get(), 120).until(
            ExpectedConditions.presenceOfElementLocated(By.id("aet2")));
    driver.get().findElement(OR.change_number_OTP2).sendKeys("8");
    new WebDriverWait(driver.get(), 120).until(
            ExpectedConditions.presenceOfElementLocated(By.id("aet3")));
    driver.get().findElement(OR.change_number_OTP3).sendKeys("8");
    new WebDriverWait(driver.get(), 120).until(
            ExpectedConditions.presenceOfElementLocated(By.id("aet4")));

    driver.get().findElement(OR.change_number_OTP4).sendKeys("8");
    
    
    
    
}
//Assertion for change number screen
public static void Settings_Change_Number_Flow()
{
	System.out.println("------- Settings_My Scree_Change_Number_screen -----");
}


//submit button for change number screen
public static void Settings_Change_Number_Submit()
{
	System.out.println("------- Settings_My Scree_Change_Number_Submit -----");
	new WebDriverWait(driver.get(), 30).until(
            ExpectedConditions.presenceOfElementLocated(By.id("tvProcess")));
 driver.get().findElement(OR.change_number_Submit_button).click();
 //Need to handle toast message
 String toastMessage3 = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
  System.out.println("Received Toast Message :"+toastMessage3);
 new WebDriverWait(driver.get(), 30).until(
            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
 driver.get().findElement(OR.Back_Arrow).click(); 
	
}

}
