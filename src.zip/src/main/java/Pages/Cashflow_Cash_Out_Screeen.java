package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class Cashflow_Cash_Out_Screeen extends Execution {

	public void Cashflow_Cash_Out_Screeen() throws InterruptedException {

		// Language Selection
		driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get().findElement(By.xpath("//*[@resource-id='com.mwallet.vfq:id/tvProceed']")).click();

		// Login
		driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMobileNo']")).click();
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMobileNo']"))
				.sendKeys(Data.un_MSISDN);

		new WebDriverWait(driver.get(), 10).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMpin']")));
		driver.get().findElement(By.xpath("//*[@resource-id = 'com.mwallet.vfq:id/etMpin']")).sendKeys(Data.Mpin_pwd);

		driver.get().navigate().back();

		new WebDriverWait(driver.get(), 30).until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@resource-id ='com.mwallet.vfq:id/login']")));
		driver.get().findElement(By.xpath("//*[@resource-id ='com.mwallet.vfq:id/login']")).click();
		Thread.sleep(5000);
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet1']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet2']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet3']")).sendKeys("8");
//		driver.get().findElement(By.xpath("//*[resource-id='com.mwallet.vfq:id/aet4']")).sendKeys("8");
		driver.get().findElement(By.xpath("(//*[@class='android.widget.TextView'])[6]")).click();
		driver.get().findElement(OR.Cash_Out).click();

	}

	public static void verticalscrollinto() {
		// Common.verticalscroll();
		Dimension size = driver.get().manage().window().getSize();
		int anchor = (int) (size.width * 0.5);
		int startPoint = (int) (size.height * 0.5);
		int endPoint = (int) (size.height * 0.1);
		new TouchAction(driver.get()).press(PointOption.point(anchor, startPoint)).waitAction()
				.moveTo(PointOption.point(anchor, endPoint)).release().perform();

	}

	public void Cash_Out() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("Cashflow_CashOut Screen validation");
	}

	public static void Cash_Out_Purpose_dropdown() {

		System.out.println(" *********  Welcome to Cash_Out      ***************");
		verticalscroll();
		driver.get().findElement(By.xpath("//*[@text='Purpose of Transfer']")).click();

	}
}
