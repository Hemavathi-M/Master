package Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Settings_Validation extends Execution {

	public void Settings_Validation() {
		System.out.println("-------Settings validation -----");

		// setting screen
		new WebDriverWait(driver.get(), 30).until(ExpectedConditions.presenceOfElementLocated(By.id("menu_settings")));
		driver.get().findElement(OR.setting_Button).click();
	}

	public void Settings_Screen_Flow() {
		System.out.println("------- Settings screen flow-----");
	}
	
	public void Settings_Screen_scroll() {
		System.out.println("------- Settings screen scroll-----");
		verticalscroll();
	}

//	public void Settings_Screen_My_profile()
//	{
//			System.out.println("------- Settings screen -----");
//			//driver.get().findElement(OR.setting_Button).click();
//	      //  driver.get().findElement(OR.My_Profile_Icon).click();
//	        
//	        try {
//				Thread.sleep(2000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			Runtime run = Runtime.getRuntime();
//			try {
//				run.exec("adb shell input keyevent 66");
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//			try {
//				Thread.sleep(5000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			driver.get().navigate().back();
//		}
}

//	public void Settings_Screen_Change_Language()
//	{
//			System.out.println("------- Settings screen -----");
//			 driver.get().findElement(OR.setting_Button).click();
//			driver.get().findElement(OR.setting_Button).click();
//			//language select
//			driver.get().findElement(OR.Change_your_language_Hindhi_RadioButton).click();
//          driver.get().findElement(OR.Change_Your_Language_Change_Button).click();
//			
//	}
//	        
//	}
