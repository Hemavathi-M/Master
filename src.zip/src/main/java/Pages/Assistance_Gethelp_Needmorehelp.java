package Pages;

import org.openqa.selenium.By;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_Gethelp_Needmorehelp extends Execution{
	
	public void Assistance_Gethelp_Needmorehelp()
	{
		driver.get().findElement(OR.Assistance_NeedMorehelp_Screen).click();
		String toastMessage3 = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
		  System.out.println("Received Toast Message :"+toastMessage3);
	}
	public static void GetHelp_Needmorehelp_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help Need more Help validation ***************");
	}
	public static void Back_to_Page() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
}
