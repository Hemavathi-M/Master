package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_Locateus extends Execution {
	public void Assistance_Locateus()
	{
		driver.get().findElement(OR.Assistance_Locateus).click();
	}
	public static void Assistance_Locateus_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help Need more Help validation ***************");
	}
	public static void Back_to_Page() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
	}
	


