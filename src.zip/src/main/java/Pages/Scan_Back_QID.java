package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Scan_Back_QID extends Execution{

	public void Back_QID() {
	System.out.println("--------------scanning Back QID-------------------");
	}

	
	
	public void BackQID_Page() {
	
		driver.get().findElement(OR.cameraBtn_Backscrn).click();
	}
}
