package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Scan_Front_QID extends Execution  {
	
	public void front_QID()
	{
		System.out.println("------------------Frontscreen QID------------");
	}

	
	public void Permission_Approval() 
	{
		driver.get().findElement(OR.clkDeny).click();
		driver.get().findElement(OR.clkAllow).click();
	
	}

	public void FrontQID_Page() {
		
		driver.get().findElement(OR.cameraBtn_frontscrn).click();
		
	}
	
}
