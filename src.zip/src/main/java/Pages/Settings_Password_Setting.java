package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Settings_Password_Setting extends Execution {
  public void Settings_Password_Setting()
  {
	  
//	  System.out.println("-------Settings Password settings Screen -----");
//		//language selection with proceed button 
//		driver.get().findElement(OR.Proceed).click();
//	//	Login screen
//		driver.get().findElement(OR.Mobile_Number).click();
//   	driver.get().findElement(OR.Mobile_Number).sendKeys(Data.un_MSISDN);
//   	driver.get().findElement(OR.M_PIN).click();
//  	driver.get().findElement(OR.M_PIN).sendKeys(Data.Mpin_pwd);
//      driver.get().findElement(OR.Login).click();
//     // driver.get().findElement(OR.setting_Button).click();
//
//      //setting screen
//      new WebDriverWait(driver.get(), 30).until(
//              ExpectedConditions.presenceOfElementLocated(By.id("menu_settings")));
//      driver.get().findElement(OR.setting_Button).click();
	 // =======================================================================================
      new WebDriverWait(driver.get(), 30).until(
            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
	  driver.get().findElement(OR.Back_Arrow).click(); 
       new WebDriverWait(driver.get(), 30).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
	 driver.get().findElement(OR.Back_Arrow).click(); 
	 new WebDriverWait(driver.get(), 30).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
	 driver.get().findElement(OR.Back_Arrow).click(); 
      driver.get().findElement(OR.Password_Setting_Arrow).click(); 
	 new WebDriverWait(driver.get(), 30).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("aetOldMPin1")));
	 driver.get().findElement(OR.Oldpin1).sendKeys("1");
	 driver.get().findElement(OR.Oldpin2).sendKeys("2");
	 driver.get().findElement(OR.Oldpin3).sendKeys("3");
	 driver.get().findElement(OR.Oldpin4).sendKeys("4");
	 driver.get().findElement(OR.Oldpin5).sendKeys("5");
	 driver.get().findElement(OR.Oldpin6).sendKeys("6");
	 
	 driver.get().findElement(OR.Newpin1).sendKeys("1");
	 driver.get().findElement(OR.Newpin2).sendKeys("1");
	 driver.get().findElement(OR.Newpin3).sendKeys("1");
	 driver.get().findElement(OR.Newpin4).sendKeys("1");
	 driver.get().findElement(OR.Newpin5).sendKeys("1");
	 driver.get().findElement(OR.Newpin6).sendKeys("1");
	 
	 driver.get().findElement(OR.ReMpin1).sendKeys("1");
	 driver.get().findElement(OR.ReMpin2).sendKeys("1");
	 driver.get().findElement(OR.ReMpin3).sendKeys("1");
	 driver.get().findElement(OR.ReMpin4).sendKeys("1");
	 driver.get().findElement(OR.ReMpin5).sendKeys("1");
	 driver.get().findElement(OR.ReMpin6).sendKeys("1");
	 
	 
	 
	 
	 
  }
  public static void Settings_Password_Setting_flow()
  {
	  System.out.println("------- password_setting -----");
  }
  
  public static void Settings_Password_Setting_change_button()
  {
	  System.out.println("------- password_setting -----");
	  driver.get().findElement(OR.Password_ChangeBtn).click();
	  String toastMessage4 = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
      System.out.println("Received Toast Message :"+toastMessage4);
      new WebDriverWait(driver.get(), 30).until(
	            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
	 driver.get().findElement(OR.Back_Arrow).click();
  }
  
}
