package Pages;

import org.openqa.selenium.By;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class OTP_Screen extends Execution{

	public void OTP_Screen() throws Exception {
		
		try {
			driver.get().findElement(OR.Username).click();
			driver.get().findElement(OR.Username).sendKeys(Data.un_MSISDN);
			driver.get().findElement(OR.m_pin).click();  
			driver.get().findElement(OR.m_pin).sendKeys(Data.Mpin_pwd);
			
			//driver.get().findElement(OR.keypad_ok).click();
			driver.get().navigate().back();
			
			driver.get().findElement(OR.login).click();
			
//			String toastMessage = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
//			  System.out.println("Received Toast Message :"+toastMessage);
			  //Thread.sleep(3000);
		} catch (Exception e)
		{
			e.printStackTrace();
			  String title= driver.get().findElement(OR.OTP_page).getText();
			  System.out.println(title);
			  
			  String title1="Enter OTP";
			  if(title.contains(title1))
			  {
				  System.out.println("Login Successfully");
			  }
			  else {
				  System.out.println("Login Unsuccessfull");
			  }
		}
		 
	}
	
	public void OTPscreen_validation() {
		System.out.println("-----------------OTP screen------------------------");
	
	}
	
	public void Return_To_Login_Screen() throws InterruptedException {
		System.out.println("-----------------Retrun to login screen --------------------");
		driver.get().findElement(OR.cancel).click();
		Thread.sleep(1000);
	}
	
	/*
	 * driver.get().findElement(OR.OTP_Pin1).click();
	 * driver.get().findElement(OR.OTP_Pin1).sendKeys(Data.OTPvalue_pin1);
	 * driver.get().findElement(OR.OTP_Pin2).click();
	 * driver.get().findElement(OR.OTP_Pin2).sendKeys(Data.OTPvalue_pin2);
	 * driver.get().findElement(OR.OTP_Pin3).click();
	 * driver.get().findElement(OR.OTP_Pin3).sendKeys(Data.OTPvalue_pin3);
	 * driver.get().findElement(OR.OTP_Pin4).click();
	 * driver.get().findElement(OR.OTP_Pin4).sendKeys(Data.OTPvalue_pin4);
	 */

	
}
