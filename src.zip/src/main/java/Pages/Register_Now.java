 package Pages;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;
import io.appium.java_client.AppiumDriver; 

public class Register_Now extends Execution{

	public void Register_Now() {
	System.out.println("------- register Now-----");
//	driver.get().findElement(OR.proceedbtn).click();
	driver.get().findElement(OR.Registernow_Btn).click();
	}

public void RegisterNow_Validation() {
	System.out.println("-------RegisterNow_page---------");
	
	  }

public void Click_scanID_Btn() {
	driver.get().findElement(OR.scanQID).click();
}

public void FrontQID_permission() {
	driver.get().findElement(OR.clkAllow).click();
}

public void FrontQID_Validation() {
	System.out.println("------------------Front QID screen validation---------------");
}

public void click_frontQID_Camera() {
	driver.get().findElement(OR.cameraBtn_frontscrn).click();
}

public void BackQID_Validation() {
	System.out.println("------------------Back QID screen validation---------------");
}
public void click_BackQID_Camera() {
	driver.get().findElement(OR.cameraBtn_Backscrn).click();
}

public void ProceedScreen_Validation() {
	
	System.out.println("-------------------Proceed screen---------------------");
}

public void click_proceedBtn() {
	
	driver.get().findElement(OR.Proceed_Btn).click();
}

public void Click_Videocamera_Btn() {
	driver.get().findElement(OR.Selfie_camera).click();		
}

public void StartRecord_ScreenValidation()
{
System.out.println("-----------------Start Record_Screen Validation---------------------");
	
}
public void Click_StartRecording_Btn()
{
	driver.get().findElement(OR.StartRecord_Btn).click();
	
}

public void VideoRecord_Validation()
{
System.out.println("------------------Video Record started------------------------");
	
}
public void GreatScreen_Validation()
{
	System.out.println("---------------great done! screen-----------------------");
	
}

public void Great_DoneSCreen()
{
	driver.get().findElement(OR.Usethis_video).click();
	
}

public void Submit_btn(){
	driver.get().findElement(OR.Submit_Btn).click();
	
}



}
