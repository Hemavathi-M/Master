package Pages;

import java.sql.Driver;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Forgot_Passsword extends Execution {

	public void Forgot_Passsword() {
		System.out.println("-------------Click Forgot password-------------------");
		driver.get().findElement(OR.forgot_password).click();
	}

	public void ForgotPassword_Validation() {

	}

	public void ForgotPassword_ClickInfo() {
		System.out.println("--------------click info page--------------------");
		driver.get().findElement(OR.click_info).click();

	}
	
	public void ForgotPassword_ClickInfoValidation() {
		System.out.println("--------------click info page--------------------");
	}
	
	public void Proceed_Forgot_Password_Page() throws InterruptedException {
		System.out.println("----------------- Proceed Forgot password screen --------------------");
		driver.get().findElement(OR.Ok).click();
		driver.get().findElement(OR.enter_phone).sendKeys(Data.un_MSISDN);
		driver.get().findElement(OR.proceed_btn).click();
		Thread.sleep(2000);
//		driver.get().findElement(OR.Back).click();
		}
	
	public void Validate_Scan_QID() {
		System.out.println("-----------------Validate Scan QID Screen--------------------");
		
	}
	
	public void Return_To_Login_Screen() throws InterruptedException {
		System.out.println("-----------------Retrun to login screen --------------------");
		driver.get().findElement(OR.cancel).click();
		Thread.sleep(1000);
		driver.get().findElement(OR.cancel).click();
	}

}
