package Pages;

import java.io.IOException;
import org.openqa.selenium.By;
import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Login_Screen extends Execution{
	
	//private static final String Toast = null;
	
	public void Login_Screen() {
		System.out.println("------- Login screen -----");
		driver.get().findElement(OR.proceedbtn).click();
	
	}
		
	public void LoginScreen_validation() {
		System.out.println("-- Login Validation------------");
		
	}
		
	}
