package Pages;

import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class New_Add_Beneficiary_Details extends Execution{
	
	public void New_Add_Beneficiary_Details()
	{
		 driver.get().findElement(OR.Cashout_Benificiary_Name).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Name).sendKeys(Data.Cashout_Benificiary_Name);
		 driver.get().findElement(OR.Cashout_Benificiary_Address1).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address1).sendKeys(Data.Cashout_Benificiary_Address1);
		 driver.get().findElement(OR.Cashout_Benificiary_Address2).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address2).sendKeys(Data.Cashout_Benificiary_Address2);
		 driver.get().findElement(OR.Cashout_Benificiary_Address3).click();
		 driver.get().findElement(OR.Cashout_Benificiary_Address3).sendKeys(Data.Cashout_Benificiary_Address3); 
		 driver.get().findElement(OR.Cashout_Mobilenum).click();
		 driver.get().findElement(OR.Cashout_Mobilenum).sendKeys(Data.Cashout_Mobilenum);
		 driver.get().findElement(OR.Cashout_Accnum).click();
		 driver.get().findElement(OR.Cashout_Accnum).sendKeys(Data.Cashout_Accnum_IBAN);
		 driver.get().findElement(OR.Cashout_Bankname).click();
//		 List Cashout_Bankname =  driver.get().findElement(OR.Cashout_Bankname).sendKeys(Data.Cashout_Bankname);
//		 System.out.println(Cashout_Bankname);
		
		 driver.get().findElement(OR.Cashout_Branchname).click();
		 driver.get().findElement(OR.Cashout_Branchname).sendKeys(Data.Cashout_Branchname);
		 driver.get().findElement(OR.Cashout_Purposetranfer).click();
		 driver.get().findElement(OR.Cashout_Purposetranfer).sendKeys(Data.Cashout_Purposetranfer);
		 driver.get().findElement(OR.Cashout_Relationship).click();
		 driver.get().findElement(OR.Cashout_Relationship).sendKeys(Data.Cashout_Relationship);
		 
		 driver.get().findElement(OR.Cashout_Proceedtoverify).click();
		 
//		 List<WebElement> myElements = driver.findElements(By.xpath("some/path//a"));
//	        System.out.println("Size of List: "+myElements.size());
//		 
		 
	}
	
	public static void New_Add_Beneficiary_Details_flow()
	{
		
	}

}
