package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Manage_Account_details_Page extends Execution {

	public void Manage_Account_details_Page()
	{
		 driver.get().findElement(OR.cashout_accout_1).click();
		 
	}
	
	public static void Settings_Manage_Acc_Details_Page()
	 {
	 	System.out.println("------- _Manage_account_screen_for_cash_out -----");
	 }
}
