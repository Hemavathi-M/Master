package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_GetHelp extends Execution{

	public void Assistance_GetHelp()
	{
		driver.get().findElement(OR.Assistance_Get_Help_Arrow).click();
	}
	public static void Assistance_GetHelp_screen_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help validation ***************");
	}
	
}
