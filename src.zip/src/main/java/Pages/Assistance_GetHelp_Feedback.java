package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_GetHelp_Feedback extends Execution{

	
	public void  Assistance_GetHelp_Feedback()
	{
		driver.get().findElement(OR.Assistance_Feedback_Screen).click();
	}
	public static void GetHelp_Feedback_Screen_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help Feedback Screen validation ***************");
	}
	public static void GetHelp_Feedback_New_Flow() throws InterruptedException 
	{
	//Adding the Inputs and get success responce
		driver.get().findElement(OR.Select_Type).click();
		
		Thread.sleep(3000);
		
		
	}
	public static void Select_Type_list_validation()
	{
		System.out.println(" ********* Select Type List  ***************");
	}
	public static void Select_Type_list() throws InterruptedException
	{
		driver.get().findElement(OR.Select_type_List1).click();
		
	}
	
	public static void Category() throws InterruptedException
	{
		driver.get().findElement(OR.Category_Type).click();
		Thread.sleep(3000);
	}
	public static void Category_validation() 
	{
		System.out.println(" *********Category List  ***************");
	}
	public static void Category_List_Flow() 
	{
		driver.get().findElement(OR.Category_Type1).click();
		driver.get().findElement(OR.write_request).click();
		driver.get().findElement(OR.write_request).sendKeys("Please Resubmit the request");
		driver.get().findElement(OR.Back_Mobile_icon).click();
		
	}
//	public void Assistance_feedback_Details_Scroll1() {
//		verticalscroll();
//	}
	public static void Attachement_Button() 
	{
		driver.get().findElement(OR.Attachement_document).click();
		
	}
	public static void Allowpopup_validation() 
	{
		System.out.println(" *********Allow popup Text***************");
	}
	public static void Allow_Button() 
	{
		driver.get().findElement(OR.Allow_Up).click();
		
	}
	public static void Attachement_validation() 
	{
		System.out.println(" *********Attachement Text***************");
	}
	public static void Attchedment1() throws InterruptedException 
	{
		
		driver.get().findElement(OR.Attachement_document1).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_image1).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_document2).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_image2).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_document3).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_image3).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Attachement_OK).click();
		Thread.sleep(3000);
		driver.get().findElement(OR.Submit_request).click();
		
	}
	
	
	public static void GetHelp_Feedback_All_Flow()
	{
		driver.get().findElement(OR.Assistance_Feedback_Screen_All).click();
		driver.get().findElement(OR.Showmore).click();
	}
	public void Assistance_feedback_Details_Scroll2() {
		verticalscroll();
	}
//	public static void GetHelp_Feedback_All_Showmore()
//	{
//		
//		driver.get().findElement(OR.Showmore).click();
//	}
	
	
	public static void GetHelp_Feedback_All_Flow_Screen()
	{
		System.out.println(" ********* Assistance Screen Get Help Feedback all Flow Screen validation ***************");
	}
	public static void GetHelp_Feedback_Open_Flow()
	{
		driver.get().findElement(OR.Assistance_Feedback_Screen_Open).click();
		driver.get().findElement(OR.Showmore).click();
	}
	public static void GetHelp_Feedback_Open_Flow_Screen()
	{
		System.out.println(" ********* Assistance Screen Get Help Feedback all Flow Screen validation ***************");
	}
	
	public static void GetHelp_Feedback_Close_Flow()
		{
			driver.get().findElement(OR.Assistance_Feedback_Screen_Close).click();
		}
		public static void GetHelp_Feedback_Close_Flow_Screen()
		{
			System.out.println(" ********* Assistance Screen Get Help Feedback Close Flow Screen validation ***************");
		}
		
		public static void Back_GetHelp_Screen() {
			System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
			driver.get().navigate().back();
		}
}
