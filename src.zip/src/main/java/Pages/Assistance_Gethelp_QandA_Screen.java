package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_Gethelp_QandA_Screen extends Execution{

	public void Assistance_Gethelp_QandA_Screen()
	{
		driver.get().findElement(OR.Assistance_Get_Help_QandA).click();
	}
	
	public static void Assistance_Gethelp_QandA_Screen_Validation()
	{
		System.out.println(" ********* Assistance Screen Get Help QandA validation ***************");
	}
	public static void Assistance_Gethelp_QandA_Search_flow()
	{
		driver.get().findElement(OR.Assistance_Get_Help_QandA_Search).click();
	}
	public static void Assistance_Gethelp_QandA_Search_validation()
	{
		System.out.println(" ********* Assistance Screen Get Help QandA validation ***************");
	}
	
	public void Back_to_Page1() {
		System.out.println("------- Settings_My Screen_Personal_Details_Back to setting screen -----");
		driver.get().navigate().back();
	}
	
}

