package Pages;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Assistance_FAQ_Screen extends Execution{

	
	public void Assistance_FAQ_Screen()
	{
		//click on FAQ arrow
		driver.get().findElement(OR.Assistance_FAQ_Arrow).click();
	}
	
	public static void Assistance_FAQ_Screen_validation()
	{
		System.out.println(" ********* Assistance Screen validation ***************");
	}
	
	
}
