package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Settings_Manage_Cash_Accounts extends Execution  {
	 public void Settings_Manage_Cash_Accounts()
	 {
		 
 
		 new WebDriverWait(driver.get(), 30).until(
		            ExpectedConditions.presenceOfElementLocated(By.id("tvProcess")));
		 driver.get().findElement(OR.change_number_Submit_button).click();
		 //Need to handle toast message
		 String toastMessage3 = driver.get().findElement(By.xpath("/hierarchy/android.widget.Toast")).getText();
	      System.out.println("Received Toast Message :"+toastMessage3);
		 new WebDriverWait(driver.get(), 30).until(
		            ExpectedConditions.presenceOfElementLocated(By.id("ivBack")));
		 driver.get().findElement(OR.Back_Arrow).click(); 
		 driver.get().findElement(OR.cashout_acc_arrow).click();
		 
		 
	 }
	 
	 public static void Settings_Cashout_manageAcc_Flow()
	 {
	 	System.out.println("------- Settings_Cashout_Manage_account_screen -----");
	 }
	 
	 public static void Manage_Account_details_Page()
		{
			 driver.get().findElement(OR.cashout_accout_1).click();
			 
		}
	 
	 public static void Settings_Manage_Acc_Details_Page()
	 {
	 	System.out.println("------- _Manage_account_screen_for_cash_out -----");
	 }

}
