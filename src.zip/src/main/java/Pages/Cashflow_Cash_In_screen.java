package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Cashflow_Cash_In_screen extends Execution {

	public void Cashflow_Cash_In_screen() throws InterruptedException {
		new WebDriverWait(driver.get(), 30).until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@class='android.widget.TextView'])[6]")));
		driver.get().findElement(By.xpath("(//*[@class='android.widget.TextView'])[6]")).click();
		
	}

	public void Cash_In() throws InterruptedException {
        Thread.sleep(2000);
		System.out.println("Cashflow_Cash Screen validation");
	}
	
	public void Cash_In_keyboard_Handle() {
		System.out.println("Minimize keyboard");
		driver.get().navigate().back();
	}
	
	public void Cash_In_Scroll() {
		System.out.println("Cash in screen scrolls");
		verticalscroll();
	}
	
	public void Cash_In_flow() throws InterruptedException {

		System.out.println(" *********  Welcome to Cash_In      ***************");
		driver.get().findElement(OR.Cash_Out).click();
		driver.get().findElement(OR.Cash_In).click();		
		verticalscroll_up();
		driver.get().findElement(OR.EnterAmountToAdd).sendKeys(Data.enterAmounToAdd);
	//	driver.get().findElement(OR.proceedbtn).click();
		
	}
}