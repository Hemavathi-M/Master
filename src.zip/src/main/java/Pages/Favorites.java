package Pages;

import Vodafone.Mobile_Money.Data;
import Vodafone.Mobile_Money.Execution;
import Vodafone.Mobile_Money.OR;

public class Favorites extends Execution {

	public void Favorites() {

//		driver.get().findElement(OR.proceedbtn).click();
//
//		driver.get().findElement(OR.Username).click();
//		driver.get().findElement(OR.Username).sendKeys(Data.un_MSISDN);
//		driver.get().findElement(OR.m_pin).click();
//		driver.get().findElement(OR.m_pin).sendKeys(Data.Mpin_pwd);
//		driver.get().findElement(OR.login).click();

		// driver.get().findElement(OR.Otp_proceedBtn).click();
		driver.get().findElement(OR.Clk_favoriteBtn).click();
	}

	public void FavScreen_validation() {
		System.out.println("-------------------FavScreen_validation------------------------------");
	}

	public void WalletToWallet_validation() {
		System.out.println("----------------WalletToWallet_validation---------------------------");
	}

	public void InternationTransfer_validation() {
		System.out.println("------------------InternationTransfer_validation-------------------------------");
	}

	public void Localtransfer_validation() {
		System.out.println("------------------ Localtransfer_validation-------------------------------");
	}

	public void Cashout_validation() {
		System.out.println("------------------Cashout_validation-------------------------------");
	}

}
